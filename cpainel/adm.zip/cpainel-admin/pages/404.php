<div class="text-center" id="notfoud">
    <img src="<?= IMAGENS ?>background/404.png" alt="" class="img-fluid w-100" style=" margin-top:-250px">
</div>