<div class="text-center h-50" id="prsp" data-aos="fade-in" data-aos-transition="2000" data-aos-duration="2500">
    <img src="<?= IMAGENS ?>logo/logotipo1_principal.svg" alt="" class="img-fluid w-100" style="height:98vh; margin-top:-60px">
</div>